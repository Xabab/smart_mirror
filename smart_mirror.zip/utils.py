class TimeConstant():
    ONE_HOUR = 36*(pow(10, 5))
    DAY = 24 * ONE_HOUR
    WEEK = 7 * DAY
    MONTH = WEEK * 4