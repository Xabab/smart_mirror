from kivy_frames.utils import BasicWidget


class News(BasicWidget):
    pass
