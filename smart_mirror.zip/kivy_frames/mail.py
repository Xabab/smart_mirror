from kivy_frames.utils import BasicWidget


class Mail(BasicWidget):
    pass
