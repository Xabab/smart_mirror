from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label


class BasicWidget(BoxLayout):
    pass


class MonoLabel(Label):
    pass


class Currency(BoxLayout):
    pass


class MonoAdaptiveLabel(MonoLabel):
    pass

