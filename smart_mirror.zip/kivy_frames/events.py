from kivy_frames.utils import BasicWidget


class Events(BasicWidget):
    pass
